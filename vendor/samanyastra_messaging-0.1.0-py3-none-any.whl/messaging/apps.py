import os

from django.apps import AppConfig
from django.db.models.signals import post_migrate


def _known_template_variables() -> dict:
    """Example input variables per known template — surfaced via
    MailTemplates.get_required_variables() for anyone building the `context`
    dict passed to send_templated_email(). Purely documentation: never read
    by send_templated_email itself, which always renders with the caller's
    own `context` (see messaging/smtp.py). Templates not listed here
    (e.g. a new .html file dropped into templates/) still get auto-registered
    below, just with an empty example dict.

    Built from settings rather than hardcoded so these examples automatically
    reflect whichever environment this runs in (dev vs prod) — no manual
    updates needed before deploying.
    """
    from django.conf import settings

    site = settings.SITE_BASE_URL
    return {
        "registration": {
            "activation_link": f"{site}/auth/verify-email/<token>/",
            "support_link": settings.SUPPORT_LINK,
        },
        "forgot_password": {
            "reset_link": f"{site}/auth/reset-password/<token>/",
        },
        "generic_invoice": {
            "invoice_number": "INV-0001",
            "invoice_date": "2026-01-01",
            "due_date": "2026-01-15",
            "customer_name": "Jane Doe",
            "customer_email": "jane@example.com",
            "items": [{"name": "Item", "quantity": 1, "unit_price": "100", "amount": "100", "currency": "₹"}],
            "currency": "₹",
            "subtotal": "100",
            "total_amount": "100",
            "payment_status": "pending",
            "payment_method": "UPI",
            "support_email": settings.DEFAULT_FROM_MAIL,
            "support_url": settings.SUPPORT_LINK,
        },
        "subscription_invoice": {
            "customer_name": "Jane Doe",
            "customer_email": "jane@example.com",
            "product_name": "Pro Plan",
            "duration_days": 30,
            "valid_till": "2026-02-01",
            "product_amount": "999",
            "gst_amount": "179.82",
            "total_amount": "1178.82",
            "transaction_id": "TXN-0001",
            "payment_method": "UPI",
        },
    }


def _seed_mail_templates(sender, **kwargs):
    """Register a MailTemplates row for every .html file in templates/.

    Runs after every `migrate` (post_migrate fires each time, not just once),
    so a new template file just needs to be dropped in — the next migrate
    picks it up automatically. Never touches a row that already exists, so
    manual edits made via the Django admin survive future deploys.
    """
    from .models import MailTemplates

    templates_dir = os.path.join(os.path.dirname(__file__), "templates")
    if not os.path.isdir(templates_dir):
        return

    known_variables = _known_template_variables()
    for filename in sorted(os.listdir(templates_dir)):
        if not filename.endswith(".html"):
            continue
        template_name = filename[: -len(".html")]
        MailTemplates.objects.get_or_create(
            template_name=template_name,
            defaults={
                "template_path": filename,
                "description": f"Auto-registered from messaging/templates/{filename}.",
                "input_variable_values": known_variables.get(template_name, {}),
                "is_active": True,
            },
        )


class MessagingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "messaging"

    def ready(self):
        post_migrate.connect(_seed_mail_templates, sender=self)
