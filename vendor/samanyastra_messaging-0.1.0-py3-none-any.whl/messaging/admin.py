from django.contrib import admin

from .models import MailTemplates, OutBounds


@admin.register(MailTemplates)
class MailTemplatesAdmin(admin.ModelAdmin):
	list_display = ("template_name", "template_path", "is_active", "created_at")
	search_fields = ("template_name", "template_path")
	list_filter = ("is_active",)


@admin.register(OutBounds)
class OutBoundsAdmin(admin.ModelAdmin):
	list_display = ("mail_template", "is_sent", "created_at")
	list_filter = ("is_sent", "mail_template")
