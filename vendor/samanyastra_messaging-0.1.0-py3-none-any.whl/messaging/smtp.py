import logging

import requests
from django.conf import settings
from django.template import Context, Template

from .models import MailTemplates, OutBounds

logger = logging.getLogger(__name__)


def _send_via_mail_service(*, subject: str, to_email: str, body: str) -> bool:
    """POST a single rendered email to the standalone mail-sending service.

    That service owns delivery and its own async dispatch (it returns
    immediately with a "queued" status), so this call is synchronous and
    plain `requests` — no Celery needed on this side.
    """
    url = f"{settings.MAIL_SERVICE_URL.rstrip('/')}/api/send-mail/"
    try:
        resp = requests.post(
            url,
            headers={"X-App-Secret": settings.MAIL_SERVICE_APP_SECRET},
            data={
                "app_id": settings.MAIL_SERVICE_APP_ID,
                "from_email": settings.DEFAULT_FROM_MAIL,
                "to_email": to_email,
                "subject": subject,
                "body": body,
                "is_html": "true",
            },
            timeout=10,
        )
    except requests.RequestException:
        logger.exception("[Email] mail service request failed for %s", to_email)
        return False

    if resp.status_code >= 400:
        logger.error(
            "[Email] mail service returned HTTP %s for %s: %s",
            resp.status_code, to_email, resp.text[:500],
        )
        return False

    logger.info("[Email] mail service accepted send to %s: %s", to_email, resp.text[:200])
    return True


def send_templated_email(template_name: str, subject: str, recipients: list[str], context: dict) -> bool:
    """
    Renders `template_name` with `context` and hands it to the standalone
    mail service (settings.MAIL_SERVICE_URL) via one REST call per recipient.
    """
    if not recipients:
        logger.error("[Email] recipients list is empty, aborting send for template '%s'.", template_name)
        raise ValueError("Recipients list cannot be empty")

    # ── Template resolution ───────────────────────────────────────────────────
    mail_template = MailTemplates.objects.filter(template_name=template_name, is_active=True).first()
    if mail_template is None:
        logger.warning("[Email] template '%s' not found in DB, auto-creating placeholder.", template_name)
        mail_template, created = MailTemplates.objects.get_or_create(
            template_name=template_name,
            defaults={
                "template_path": f"{template_name}.html",
                "description": f"Autocreated template mapping for {template_name}",
                "input_variable_values": {},
                "is_active": True,
            },
        )
        logger.info("[Email] template '%s' %s.", template_name, "created" if created else "found (race)")

    # ── Template rendering ────────────────────────────────────────────────────
    try:
        template_string = mail_template.get_template_string()
        mail_body = Template(template_string).render(Context(context or {}))
    except Exception:
        logger.exception("[Email] template rendering failed for '%s'.", template_name)
        raise

    # ── Send via the mail service, one call per recipient ────────────────────
    # (list comprehension, not all(generator) — a generator would short-circuit
    # on the first failure and skip sending to the remaining recipients)
    results = [
        _send_via_mail_service(subject=subject, to_email=recipient, body=mail_body)
        for recipient in recipients
    ]
    is_sent = all(results)

    # ── Persist outbound record ───────────────────────────────────────────────
    OutBounds.objects.create(
        mail_template=mail_template,
        to_mail=recipients,
        body=mail_body,
        is_sent=is_sent,
    )

    if is_sent:
        logger.info("[Email] ✓ handed off to mail service | subject='%s' to=%s", subject, recipients)
    else:
        logger.error(
            "[Email] ✗ mail service rejected send | subject='%s' to=%s — see errors above.",
            subject, recipients,
        )

    return is_sent


def send_email_with_attachment(*args, **kwargs):
    raise NotImplementedError("Attachment sending is not implemented yet.")
